package visa;

public class Visa {

	public boolean verificar(String nome, String numero, double valor, int validadeMes, int validadeAno) {
		
		return valor < 100; // um exemplo soh para testar !!!
	}
	
}
