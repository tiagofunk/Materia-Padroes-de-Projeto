package mastercard;

public class MasterCard {

	public boolean aprovar(String nome, String numero, double valor, String validade) {
		
		return valor < 100; // um exemplo soh para testar !!!
		
	}
	
}
