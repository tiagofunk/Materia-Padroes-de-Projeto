package cliente;

public interface ValidadorEndereco {

	void validar(Cliente cliente) throws Exception;
	
}
