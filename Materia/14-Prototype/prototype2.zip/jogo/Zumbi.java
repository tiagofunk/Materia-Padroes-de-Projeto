package jogo;

public class Zumbi extends Inimigo {

	public Zumbi() {
		super(50, 2);
	}

}
