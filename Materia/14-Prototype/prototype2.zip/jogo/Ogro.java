package jogo;

public class Ogro extends Inimigo {

	public Ogro() {
		super(100, 5);
	}

}
