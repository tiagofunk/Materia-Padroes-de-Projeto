package ordenar;

public interface Ordenador {

	void ordenar(int[] itens);
	
}
