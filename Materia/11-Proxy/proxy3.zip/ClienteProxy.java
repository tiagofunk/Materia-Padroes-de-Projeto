
public class ClienteProxy implements Cliente {

	private boolean carregado;
	private int codigo;
	private ClienteReal cliente;
	
	public ClienteProxy(int codigo) {
		this.codigo = codigo;
		this.carregado = false;
	}
	
	@Override
	public int getCodigo() {
		return this.codigo;
	}

	@Override
	public String getNome() {
		if (!carregado)
			carregar();
		return cliente.getNome();
	}
	
	private void carregar() {
		this.carregado = true;
		
		System.out.println("Carregando os dados do cliente " + getCodigo());
 
		// ler a linha da tabela e popular os atributos do objeto
		this.cliente = new ClienteReal(getCodigo());
		this.cliente.setNome(getCodigo() + "-nome");
	}

	@Override
	public void setNome(String nome) {
		if (!carregado)
			carregar();
		cliente.setNome(nome);
	}

}
