import java.util.ArrayList;
import java.util.List;

public class ClientesDao {

	public List<Cliente> carregarClientes() throws Exception {

		List<Cliente> ret = new ArrayList<>(100); // sabe-se jah a quantidade de linhas
		
		for (int i = 0; i < 100; i++) {
			ret.add(new ClienteProxy(i+1));
		}
		
		return ret;
	}
}
