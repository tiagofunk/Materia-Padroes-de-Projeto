
public interface Cliente {
	
	int getCodigo();
	String getNome();
	void setNome(String nome);
	
}
