public interface Arma {

	void atirar();
	void alcanceVisao();

	void atirarComCalma();
}
