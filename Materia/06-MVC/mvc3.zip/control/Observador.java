package control;

public interface Observador {

	void carregarCampos(String texto, String numero, boolean booleano);

}
