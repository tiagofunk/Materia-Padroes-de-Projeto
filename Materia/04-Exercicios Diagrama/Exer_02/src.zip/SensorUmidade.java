public class SensorUmidade implements Sensor {

	@Override
	public double getMedicao() {
		return 0.0;
	}

}
