public class SensorTemperatura implements Sensor {

	@Override
	public double getMedicao() {
		return 0.0;
	}

}
