public class DefesaCivil {
	
	private EstacaoMeteorologia estacao;

	public void abrir() {
		
	}
	
	public void atualizar() {
		
	}

	public EstacaoMeteorologia getEstacao() {
		return estacao;
	}

	public void setEstacao(EstacaoMeteorologia estacao) {
		this.estacao = estacao;
	}
	
}
