public interface ObservadorTempo {

	public void atualizar( EstacaoMeteorologia estacao );
	
}
