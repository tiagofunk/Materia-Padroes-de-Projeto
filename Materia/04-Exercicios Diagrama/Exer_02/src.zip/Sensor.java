public interface Sensor {

	public double getMedicao();
}
