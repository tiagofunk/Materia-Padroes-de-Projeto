import java.util.List;

public class EstacaoMeteorologia {
	
	private SensorUmidade sensorUmidade;
	private SensorTemperatura sensorTemperatura;
	private List<ObservadorTempo> observadores;

	public void ligar() {
		
	}
	
	public double getTemperatura() {
		return sensorUmidade.getMedicao();
	}
	
	public double getUmidade() {
		return 0.0;
	}
	
	public void anexar( ObservadorTempo obs ) {
		
	}
	
	public void desanexar( ObservadorTempo obs ) {
		
	}
	
	public void notificar() {
		double temperatura, umidade;
		for( ObservadorTempo obs: observadores ) {
			obs.atualizar( this );
			
			//this.getTemperatura();			
			//temperatura = sensorTemp.getMedicao();
			
			//this.getUmidade();
			//umidade = sensorUmidade.getMedicao();
		}
	}

	public SensorUmidade getSensorTemp() {
		return sensorUmidade;
	}

	public void setSensorTemp(SensorUmidade sensorTemp) {
		this.sensorUmidade = sensorTemp;
	}

	public SensorTemperatura getSensorUmidade() {
		return sensorTemperatura;
	}

	public void setSensorUmidade(SensorTemperatura sensorUmidade) {
		this.sensorTemperatura = sensorUmidade;
	}
	
}
