public class DispositivoConsole implements ObservadorTempo {

	@Override
	public void atualizar(EstacaoMeteorologia estacao) {
		estacao.getTemperatura();
                estacao.getUmidade();
	}

	
}
