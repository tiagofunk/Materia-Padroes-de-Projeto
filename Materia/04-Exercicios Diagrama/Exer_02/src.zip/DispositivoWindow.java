public class DispositivoWindow implements ObservadorTempo {

	@Override
	public void atualizar(EstacaoMeteorologia estacao) {
		estacao.getTemperatura();
                estacao.getUmidade();
	}

}
