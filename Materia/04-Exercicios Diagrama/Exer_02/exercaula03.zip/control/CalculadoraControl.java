package control;

/**
 *
 * @author adilsonv77
 */
public interface CalculadoraControl extends Observado {

    int somar(int val1, int val2);
    
}
