package control;

/**
 *
 * @author adilsonv
 */
public interface Observador {

    void notificar(int valor);
    
}
