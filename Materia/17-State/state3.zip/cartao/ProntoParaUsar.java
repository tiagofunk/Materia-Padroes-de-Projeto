package cartao;

public class ProntoParaUsar extends CartaoEstado {

	private Cartao cartao;

	public ProntoParaUsar(Cartao cartao) {
		this.cartao = cartao;
	}

	@Override
	public void entrarPin(String pin) throws Exception {
		if (pin.equals("XXXX")) {
			if (cartao.getTentativas() >= 3) {
				// bloquear o cartao
			} else {
				cartao.setEstado(new ProntoParaPagamento(cartao));
			}
			cartao.setTentativas(cartao.getTentativas()+1);
		} else {
			throw new Exception("Erro de PIN");
		}
	}

	@Override
	public void fazerPagamento() throws Exception {
		throw new Exception("N\u00E3o podes fazer o pagamento.");
	}

	@Override
	public String toString() {
		return "ProntoParaUsar";
	}
}
