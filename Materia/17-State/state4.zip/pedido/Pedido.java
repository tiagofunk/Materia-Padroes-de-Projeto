package pedido;

public class Pedido {

	public void setEstado(Object estado) {
		System.out.println(estado);
	}
	
	public Pedido() {
		
	}
	
	public void analisar() throws Exception  {
		
	}
	
	public void suspender() throws Exception  {
		
	}
	
	public void retomar() throws Exception  {
		
	}
	
	public void cancelar() throws Exception  {
		
	}
	
	public void aprovar() throws Exception  {
		
	}
	
	public void atender() throws Exception  {
		
	}
}
