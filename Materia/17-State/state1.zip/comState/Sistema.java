package comState;

public class Sistema {

	public static void main(String[] args) {
		
		Ventilador v = new Ventilador();
		v.pressionarBotao();
		
		v.pressionarBotao();
		
		v.pressionarBotao();
		
		v.pressionarBotao();
		
		v.pressionarBotao();

	}

}
