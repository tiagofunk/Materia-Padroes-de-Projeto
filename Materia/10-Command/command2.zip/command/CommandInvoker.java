package command;

public class CommandInvoker {

	public void execute(Command comm, int qtdade) {
		comm.execute(qtdade);
	}

	public void undo() {
		// TODO Auto-generated method stub
		
	}

	public void redo() {
		// TODO Auto-generated method stub
		
	}

}

