package comandos.arcondicionado;

import comandos.Command;

public interface ComandoArCondicionado extends Command {

}
