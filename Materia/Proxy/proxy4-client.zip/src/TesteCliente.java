import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class TesteCliente {

	public static void main(String[] args) {
 		  System.setProperty("java.security.policy", "proxy4.policy");
		  
 		  if (System.getSecurityManager() == null) {
	            System.setSecurityManager(new SecurityManager());
	        }
	        try {
	            String nome = "pedido001";
	            Registry registry = LocateRegistry.getRegistry();
	            PedidoRemote pedido = (PedidoRemote) registry.lookup(nome);
	            pedido.addItem(100);
	            pedido.addItem(50);
	        } catch (Exception e) {
	            System.err.println("Excecao:");
	            e.printStackTrace();
	        }
	}

}
