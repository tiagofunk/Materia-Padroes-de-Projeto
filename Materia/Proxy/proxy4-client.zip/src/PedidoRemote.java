import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PedidoRemote extends Remote {

	void addItem(int qtdade) throws RemoteException;
}
