import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class AppServidor {

	public static void main(String[] args) {
		 System.setProperty("java.security.policy", "proxy4.policy");
		 if (System.getSecurityManager() == null) {
	            System.setSecurityManager(new SecurityManager());
	        }
	        try {
	        	Registry registry = LocateRegistry.createRegistry(1099);
	        	
	        	String nome = "pedido001";
	        	Pedido pedido = new Pedido();
	            PedidoRemote stub =
	                (PedidoRemote) UnicastRemoteObject.exportObject(pedido, 0);
	            
	            registry.rebind(nome, stub);
	            System.out.println("Pedido pronto");
	        } catch (Exception e) {
	            System.err.println("Excecao no servidor:");
	            e.printStackTrace();
	        }	}

}
