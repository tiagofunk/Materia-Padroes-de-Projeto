import java.rmi.RemoteException;

public class Pedido implements PedidoRemote {

	private int qtdade;

	@Override
	public void addItem(int qtdade) throws RemoteException {
		this.qtdade += qtdade;
		
		System.out.println(this.qtdade);
	}

}
