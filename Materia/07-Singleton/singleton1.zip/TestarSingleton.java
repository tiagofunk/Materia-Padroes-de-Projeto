
public class TestarSingleton {

	public static void main(String[] args) {

		Singleton s = Singleton.getInstance();
		s.facaAlgo();

	}

}
