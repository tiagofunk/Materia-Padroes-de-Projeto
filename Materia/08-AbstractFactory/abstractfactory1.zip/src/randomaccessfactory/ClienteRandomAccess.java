package randomaccessfactory;

import abstractfactory.ClienteDados;

public class ClienteRandomAccess extends ClienteDados {

}
