package randomaccessfactory;

import abstractfactory.PedidoDados;

public class PedidoRandomAccess extends PedidoDados {

}
