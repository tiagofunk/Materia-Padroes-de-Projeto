package abstractfactory;

public abstract class PedidoDados {

}
