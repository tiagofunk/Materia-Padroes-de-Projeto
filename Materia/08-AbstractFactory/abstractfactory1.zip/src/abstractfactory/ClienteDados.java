package abstractfactory;

public abstract class ClienteDados {

	public void imprimir() {
		System.out.println(this.getClass().getSimpleName());
	}
}
