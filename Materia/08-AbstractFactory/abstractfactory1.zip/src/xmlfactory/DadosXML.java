package xmlfactory;

import abstractfactory.ClienteDados;
import abstractfactory.DadosFactory;
import abstractfactory.PedidoDados;

public class DadosXML extends DadosFactory {

	@Override
	public ClienteDados createCliente() {
		return new ClienteXML();
	}

	@Override
	public PedidoDados createPedido() {
		return new PedidoXML();
	}

}
