package xmlfactory;

import abstractfactory.PedidoDados;

public class PedidoXML extends PedidoDados {

}
