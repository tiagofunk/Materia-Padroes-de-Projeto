package xmlfactory;

import abstractfactory.ClienteDados;

public class ClienteXML extends ClienteDados {


}
