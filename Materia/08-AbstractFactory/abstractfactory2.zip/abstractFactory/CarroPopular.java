package abstractFactory;

public interface CarroPopular {
	
	void exibirInfoPopular();
	
}
