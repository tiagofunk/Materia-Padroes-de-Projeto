package abstractFactory;

public interface CarroSedan {
	
	void exibirInfoSedan();
}
