package br.udesc.ppr55.observer.prj1.solucao;

public interface Observador {

	void atualizarValorA(int valorA);
	void atualizarValorB(int valorB);
	void atualizarValorC(int valorC);

}
