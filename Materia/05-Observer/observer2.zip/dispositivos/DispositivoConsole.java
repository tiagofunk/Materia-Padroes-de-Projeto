package dispositivos;

public class DispositivoConsole {

	
}
