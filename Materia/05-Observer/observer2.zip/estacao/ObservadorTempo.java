package estacao;

public interface ObservadorTempo {

	void atualizar(EstacaoMeteorologica estacao);
	
}
