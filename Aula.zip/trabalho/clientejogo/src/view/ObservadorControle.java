package view;

public interface ObservadorControle {
    
    public void prepararTela();

    public void informar(String mensagem);
    
}
