package model.abstrato;

public interface Peca {
    
}
