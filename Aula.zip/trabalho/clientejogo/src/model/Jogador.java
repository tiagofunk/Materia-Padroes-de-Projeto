package model;

public class Jogador {
	
	private Time time;

	public Jogador(Time time) {
		super();
		this.time = time;
	}

	public Time getTime() {
		return time;
	}
    
}
