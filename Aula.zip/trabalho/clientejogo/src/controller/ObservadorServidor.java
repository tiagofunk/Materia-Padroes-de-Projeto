package controller;

public interface ObservadorServidor {

    public void encaminharMensagemRecebida(String mensagem);
    
}
