package model;

public interface ObservadorCliente {

    public void informar( String mensagem, int destino );
}
