#!/bin/bash

java -jar "/home/tiago/Dropbox/Engenharia de Softwares/5-Quinto Semestre/Padrões de Projeto/Trabalho/ServidorJogo/dist/ServidorJogo.jar" &

java -jar "/home/tiago/Dropbox/Engenharia de Softwares/5-Quinto Semestre/Padrões de Projeto/Trabalho/ClienteJogo/dist/ClienteJogo.jar" &

java -jar "/home/tiago/Dropbox/Engenharia de Softwares/5-Quinto Semestre/Padrões de Projeto/Trabalho/ClienteJogo/dist/ClienteJogo.jar" &

